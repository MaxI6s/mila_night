# Meca500 torque monitor

Live CLI monitor of joint torques on a Meca500. It compares measured torque with a model
that includes gravity (from the URDF inertias) and watches the torque rate dΔ/dt to catch
sudden contacts. It only monitors: your program or the web portal keeps control of the robot.

```
pip install mecademicpy numpy rich
python meca_torque_monitor.py --ip 192.168.0.100
python meca_torque_monitor.py --sim                 # no robot needed, to try the display
```

Files: `meca_torque_monitor.py` (CLI), `urdf_dynamics.py` (numpy inverse dynamics from a URDF,
validated against Pinocchio to 1e-15 Nm), `meca500.urdf` (copied from `meca500_description`).

## How it connects

1. **Setup** (~2 s, only if nobody holds the control port): connects in control mode, adds the
   streams it needs (`JointTorq`, `TargetJointTorq`, `JointPos`, `TargetJointVel`) to the ones
   already enabled, sets the monitoring interval (`--monitor-interval`, 5 ms), reads the payload
   (`GetPayload`), then disconnects. The robot keeps these settings until it is rebooted.
2. **Monitoring**: connects to the monitoring port (10001) only, and reconnects if the link drops.

Start the tool before your program connects. If the control port is already taken, setup is
skipped and the tool uses the streams already enabled; the header says which are missing and the
line to add to your program:
`robot.SetRealTimeMonitoring('JointTorq', 'TargetJointTorq', 'JointPos', 'TargetJointVel')`.
`SetRealTimeMonitoring` is not cumulative: if your program calls it with its own list, include these.
`--no-setup` skips the setup step entirely.

## What is displayed (per joint, all in % of max torque)

| Column | Meaning |
|---|---|
| Load | \|measured torque\| bar, green < 50 %, yellow < 80 %, red above |
| Meas / Model | measured torque / expected torque (see `--model`) |
| Δ | measured − model, centered bar, coloured against `--delta-threshold` |
| dΔ/dt, peak | low-pass filtered derivative of Δ in %/s, and peak held for 2 s |

Events (threshold crossings, with hysteresis) are listed under the table.

## Model (`--model`)

* `robot+gravity` (default): robot calculated torque (`GetRtTargetJointTorq`) + URDF gravity torque.
  Keeps the robot's own feed-forward (which includes motor/rotor inertia) and adds the missing gravity.
* `urdf`: full URDF inverse dynamics (gravity + link inertia from target velocity/acceleration).
  No rotor inertia and no friction, so expect larger Δ during fast moves.
* `robot`: robot calculated torque only (what the firmware compares by default, no gravity).

## Calibration (recommended)

The robot reports torque in % of an internal max torque that is not published, and the URDF
inertias are not identified. Out of the box, the URDF `effort` limits (8.4 / 8.4 / 8.4 / 1.25 /
1.25 / 0.75 Nm) are used as 100 %. Calibration fits, per joint,
`meas% − calc% = scale · gravity_Nm + offset` over static poses:

```
python meca_torque_monitor.py --ip 192.168.0.100 --calibrate torque_calib.json
```

While it runs, jog the robot from the web portal (or run a program) through 8+ varied poses,
resting ~2 s in each (large changes on J2, J3, J5; J4 ±90° with J5 bent). Ctrl+C fits and saves.

`torque_calib.json` next to the script is loaded automatically (otherwise `--calib FILE`).
Joints whose gravity barely changes (J1, J6) or whose fit is weak (R² < 0.8) keep the default.
A negative fitted scale means the robot's torque sign is opposite to the URDF axis on that joint.

## Useful options

| Option | Default | |
|---|---|---|
| `--delta-threshold` | 10 % | Δ alarm |
| `--rate-threshold` | 300 %/s | dΔ/dt alarm |
| `--rate-source` | delta | `measured` to differentiate the raw torque instead |
| `--filter-hz` | 8 Hz | low-pass before/after differentiation (lower = smoother, slower) |
| `--payload-mass`, `--payload-com X Y Z` | read from robot at setup | kg, mm in flange frame |
| `--monitor-interval` | 0.005 s | streaming period set at setup (0 = leave unchanged) |
| `--no-setup` | off | never use the control port |
| `--csv FILE` | – | log every sample (meas, model, Δ, rate per joint) |

Tuning thresholds: run your normal cycle with `--csv`, then set the thresholds ~1.5–2× above
the largest |Δ| and |dΔ/dt| seen.

## Notes

* Firmware 11.1+ is needed for the robot calculated torque; without it, it is treated as 0.
* The payload is read once at setup. If your program changes it (`SetPayload`), restart the tool
  or pass `--payload-mass/--payload-com`. The monitoring port does not report it.
* Changing the monitoring interval affects every client of the robot (they get data more often).
* Assumes the robot is mounted upright (gravity along −Z of the base) and that the URDF
  `link_6` frame is the flange frame (FRF) for the payload COM.
* Friction is not modeled: during motion it shows up in Δ (a few %); dΔ/dt is much less
  sensitive to it, which is why it is the better contact signal.
