"""
urdf_dynamics.py - Minimal rigid-body dynamics for serial arms described by a URDF.

numpy only (no ROS install needed). Parses the <joint>/<inertial> data of a URDF
and computes inverse dynamics with the recursive Newton-Euler algorithm (RNEA):

    tau = M(q) qdd + C(q, qd) qd + g(q)

Supports revolute/continuous joints and fixed joints (fixed-joint children are
lumped into the preceding moving link). Prismatic joints are not supported.

Example:
    chain = SerialChain.from_urdf("meca500.urdf")
    chain.set_payload(mass=0.2, com=(0, 0, 0.03))   # kg, m, in flange (last link) frame
    tau_g = chain.gravity(q)                         # Nm, q in rad
    tau = chain.rnea(q, qd, qdd)                     # Nm
"""

from dataclasses import dataclass
import xml.etree.ElementTree as ET

import numpy as np

GRAVITY = np.array([0.0, 0.0, -9.81])


# ----------------------------------------------------------------------------- math helpers
def rpy_to_rot(r, p, y):
    """URDF convention: R = Rz(yaw) @ Ry(pitch) @ Rx(roll)."""
    cr, sr, cp, sp, cy, sy = np.cos(r), np.sin(r), np.cos(p), np.sin(p), np.cos(y), np.sin(y)
    return np.array([
        [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
        [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
        [-sp, cp * sr, cp * cr],
    ])


def axis_angle_rot(axis, angle):
    """Rodrigues rotation about a unit axis."""
    x, y, z = axis
    c, s = np.cos(angle), np.sin(angle)
    C = 1.0 - c
    return np.array([
        [c + x * x * C, x * y * C - z * s, x * z * C + y * s],
        [y * x * C + z * s, c + y * y * C, y * z * C - x * s],
        [z * x * C - y * s, z * y * C + x * s, c + z * z * C],
    ])


def _cross(a, b):
    """3D cross product (np.cross has ~15 us of overhead per call on small vectors)."""
    a0, a1, a2 = a
    b0, b1, b2 = b
    return np.array([a1 * b2 - a2 * b1, a2 * b0 - a0 * b2, a0 * b1 - a1 * b0])


def _vec(text, default="0 0 0"):
    return np.array([float(v) for v in (text or default).split()])


def _origin(el):
    """(R, p) of an <origin> element (identity if absent)."""
    if el is None:
        return np.eye(3), np.zeros(3)
    return rpy_to_rot(*_vec(el.get("rpy"))), _vec(el.get("xyz"))


# ----------------------------------------------------------------------------- rigid bodies
@dataclass
class Body:
    mass: float
    com: np.ndarray       # center of mass, in link frame [m]
    inertia: np.ndarray   # 3x3 inertia about the COM, expressed in link frame [kg m^2]

    @staticmethod
    def zero():
        return Body(0.0, np.zeros(3), np.zeros((3, 3)))

    def transformed(self, R, p):
        """Same body expressed in a parent frame where this frame has pose (R, p)."""
        return Body(self.mass, R @ self.com + p, R @ self.inertia @ R.T)

    def combined(self, other):
        """Lump two bodies expressed in the same frame (parallel-axis theorem)."""
        m = self.mass + other.mass
        if m <= 0.0:
            return Body.zero()
        c = (self.mass * self.com + other.mass * other.com) / m
        inertia = np.zeros((3, 3))
        for b in (self, other):
            d = b.com - c
            inertia += b.inertia + b.mass * (d @ d * np.eye(3) - np.outer(d, d))
        return Body(m, c, inertia)


def _parse_inertial(link_el):
    inertial = link_el.find("inertial") if link_el is not None else None
    if inertial is None:
        return Body.zero()
    R, p = _origin(inertial.find("origin"))
    mass = float(inertial.find("mass").get("value"))
    i = inertial.find("inertia")
    g = lambda k: float(i.get(k, 0.0))
    I_local = np.array([
        [g("ixx"), g("ixy"), g("ixz")],
        [g("ixy"), g("iyy"), g("iyz")],
        [g("ixz"), g("iyz"), g("izz")],
    ])
    return Body(mass, p, R @ I_local @ R.T)


# ----------------------------------------------------------------------------- serial chain
class SerialChain:
    """Serial chain of revolute joints. Joint i rotates body i about axis[i] (in body i frame)."""

    def __init__(self, names, R0, p0, axes, bodies, effort, lower, upper):
        self.names = names
        self.R0 = R0          # fixed rotation of joint i origin, in parent body frame
        self.p0 = p0          # position of joint i origin, in parent body frame
        self.axes = axes      # unit joint axes, in body i frame
        self.bodies = bodies  # inertial data of the bodies moved by each joint
        self._bodies_no_payload = list(bodies)
        self.effort = np.array(effort)
        self.lower = np.array(lower)
        self.upper = np.array(upper)
        self.payload = (0.0, np.zeros(3))

    @property
    def n(self):
        return len(self.names)

    @classmethod
    def from_urdf(cls, path, tip_link=None):
        root = ET.parse(path).getroot()
        links = {l.get("name"): l for l in root.findall("link")}
        joints = root.findall("joint")
        children = {}
        child_links = set()
        for j in joints:
            children.setdefault(j.find("parent").get("link"), []).append(j)
            child_links.add(j.find("child").get("link"))
        roots = [name for name in links if name not in child_links]
        if len(roots) != 1:
            raise ValueError(f"URDF must have exactly one root link, found {roots}")

        names, R0, p0, axes, bodies, effort, lower, upper = [], [], [], [], [], [], [], []
        R_acc, p_acc = np.eye(3), np.zeros(3)  # pending fixed transform since the last moving body
        link = roots[0]
        while link in children and link != tip_link:
            if len(children[link]) > 1:
                raise ValueError(f"Branching at link '{link}' - pass tip_link to select the chain")
            j = children[link][0]
            child = j.find("child").get("link")
            Rj, pj = _origin(j.find("origin"))
            R, p = R_acc @ Rj, R_acc @ pj + p_acc
            jtype = j.get("type")
            body = _parse_inertial(links.get(child))
            if jtype == "fixed":
                R_acc, p_acc = R, p
                if bodies:  # lump into the last moving body (bodies before the 1st joint are fixed base)
                    bodies[-1] = bodies[-1].combined(body.transformed(R, p))
            elif jtype in ("revolute", "continuous"):
                axis = _vec(j.find("axis").get("xyz") if j.find("axis") is not None else "1 0 0")
                lim = j.find("limit")
                names.append(j.get("name"))
                R0.append(R)
                p0.append(p)
                axes.append(axis / np.linalg.norm(axis))
                bodies.append(body)
                effort.append(float(lim.get("effort", "nan")) if lim is not None else np.nan)
                lower.append(float(lim.get("lower", "-inf")) if lim is not None else -np.inf)
                upper.append(float(lim.get("upper", "inf")) if lim is not None else np.inf)
                R_acc, p_acc = np.eye(3), np.zeros(3)
            else:
                raise NotImplementedError(f"Joint type '{jtype}' ({j.get('name')}) not supported")
            link = child
        if not names:
            raise ValueError("No revolute joint found in URDF")
        return cls(names, R0, p0, axes, bodies, effort, lower, upper)

    def set_payload(self, mass, com=(0.0, 0.0, 0.0)):
        """Point-mass payload attached to the last body. com in last-body (flange) frame, meters."""
        self.payload = (float(mass), np.asarray(com, dtype=float))
        self.bodies = list(self._bodies_no_payload)
        if mass > 0:
            self.bodies[-1] = self.bodies[-1].combined(Body(float(mass), self.payload[1], np.zeros((3, 3))))

    def rnea(self, q, qd, qdd, gravity=GRAVITY):
        """Joint torques [Nm] for joint positions [rad], velocities [rad/s], accelerations [rad/s^2]."""
        n = self.n
        w, wd = np.zeros(3), np.zeros(3)
        a = -np.asarray(gravity)  # gravity modeled as an upward acceleration of the base
        Rs, F, N = [], [], []
        for i in range(n):
            z, b = self.axes[i], self.bodies[i]
            R = self.R0[i] @ axis_angle_rot(z, q[i])   # body i orientation in parent frame
            Rt, p = R.T, self.p0[i]
            a = Rt @ (a + _cross(wd, p) + _cross(w, _cross(w, p)))
            w_parent = Rt @ w
            w = w_parent + z * qd[i]
            wd = Rt @ wd + _cross(w_parent, z * qd[i]) + z * qdd[i]
            ac = a + _cross(wd, b.com) + _cross(w, _cross(w, b.com))
            F.append(b.mass * ac)
            N.append(b.inertia @ wd + _cross(w, b.inertia @ w))
            Rs.append(R)

        tau = np.zeros(n)
        f, nm = np.zeros(3), np.zeros(3)
        for i in reversed(range(n)):
            if i < n - 1:
                f_c = Rs[i + 1] @ f
                n_c = Rs[i + 1] @ nm + _cross(self.p0[i + 1], f_c)
            else:
                f_c, n_c = np.zeros(3), np.zeros(3)
            f = F[i] + f_c
            nm = N[i] + n_c + _cross(self.bodies[i].com, F[i])
            tau[i] = nm @ self.axes[i]
        return tau

    def gravity(self, q, gravity=GRAVITY):
        """Static torques [Nm] needed to hold the arm at q [rad]."""
        z = np.zeros(self.n)
        return self.rnea(q, z, z, gravity)
