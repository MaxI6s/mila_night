#!/usr/bin/env python3
"""
meca_torque_monitor.py - Live joint torque monitor for the Meca500 (mecademicpy + URDF model).

Monitoring only: the tool never keeps control of the robot, so your program or the web
portal can drive it while it runs.
  1. Setup (a few seconds, only if the control port is free): connects in control mode,
     adds the real-time streams it needs to the ones already enabled, sets the monitoring
     interval, reads the payload, then disconnects. These settings stay active until the
     robot is rebooted.
  2. Monitoring: connects to the monitoring port (10001) only.
If the control port is busy, setup is skipped and the tool uses whatever streams are
already enabled (it tells you which ones are missing).

For each joint it shows:
  * Load      |measured torque| as a % of the joint's max torque (bar)
  * Model     expected torque in %:
                robot+gravity (default): robot calculated torque + URDF gravity torque
                urdf:  full URDF inverse dynamics (gravity + inertia, no rotor inertia/friction)
                robot: robot calculated torque only (no gravity, like the firmware)
  * Delta     measured - model, in % (centered bar)
  * dDelta/dt rate of change of the delta, in %/s, low-pass filtered, with peak hold.
              Static offsets (gravity model error, stiction) drop out of this signal,
              so a sudden contact shows up even if the static delta is not zero.

Calibration (recommended once): measured torques are a % of an internal max torque that
is not published, and the URDF inertias are not identified. --calibrate records static
poses while you jog the robot (web portal or your program), fits per joint
measured% = scale * gravity_Nm + offset, and saves a JSON file the monitor loads automatically.

Requirements: pip install mecademicpy numpy rich      (firmware 11.1+ for calculated torque)

Examples:
  python meca_torque_monitor.py --ip 192.168.0.100
  python meca_torque_monitor.py --ip 192.168.0.100 --model urdf --csv run1.csv
  python meca_torque_monitor.py --ip 192.168.0.100 --calibrate torque_calib.json
  python meca_torque_monitor.py --sim            # no robot: simulated data, to try the display
"""

import argparse
import csv
import json
import math
import os
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

import numpy as np
from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from urdf_dynamics import SerialChain

HERE = os.path.dirname(os.path.abspath(__file__))
N = 6
DEFAULT_CALIB = os.path.join(HERE, "torque_calib.json")

# Real-time streams used by the monitor: (name for SetRealTimeMonitoring, status code, required?)
STREAMS = (
    ("JointTorq", 2213, True),         # measured torque
    ("TargetJointTorq", 2203, False),  # robot calculated torque (else treated as 0)
    ("JointPos", 2210, False),         # measured position (else target position, always sent)
    ("TargetJointVel", 2202, False),   # target velocity (else derived from position)
)
STREAMS_LINE = "robot.SetRealTimeMonitoring(" + ", ".join(f"'{n}'" for n, _, _ in STREAMS) + ")"


# ============================================================================ robot setup
def setup_robot(ip, interval, log):
    """Short control-mode session: merge our streams into the enabled ones, set the
    monitoring interval, read the payload, disconnect. Returns the payload or None."""
    import mecademicpy.robot as mdr
    r = mdr.Robot()
    r.Connect(address=ip)  # raises if another client holds the control port
    try:
        current = [int(c) for c in r.GetRealTimeMonitoring()]
        wanted = [code for _, code, _ in STREAMS]
        missing = [c for c in wanted if c not in current]
        if missing:
            # SetRealTimeMonitoring is not cumulative: resend what was already enabled + ours
            r.SetRealTimeMonitoring(*(current + missing))
            log(f"enabled streams {', '.join(n for n, c, _ in STREAMS if c in missing)} "
                f"(kept {len(current)} already enabled)")
        else:
            log("required streams already enabled")
        if interval and interval > 0:
            r.SetMonitoringInterval(interval)
            log(f"monitoring interval set to {interval * 1000:g} ms")
        payload = None
        try:
            p = r.GetPayload()
            payload = (p.mass, (p.x, p.y, p.z))
            log(f"payload read from robot: {p.mass:g} kg @ ({p.x:g}, {p.y:g}, {p.z:g}) mm")
        except Exception as e:
            log(f"could not read payload ({e})")
        r.WaitEndOfCycle(timeout=2.0)  # make sure the robot applied the new configuration
        return payload
    finally:
        r.Disconnect()


# ============================================================================ data sources
@dataclass
class Sample:
    t: float                    # robot timestamp [s]
    q: np.ndarray               # measured joint positions [rad]
    qd: Optional[np.ndarray]    # target joint velocities [rad/s] (None if not streamed)
    tau_meas: np.ndarray        # measured torque [% of max]
    tau_calc: np.ndarray        # robot calculated (target) torque [% of max]
    calc_ok: bool = True


def _live(ts_data):
    """True if a real-time field is actually being streamed (mecademicpy zero-fills disabled ones)."""
    return bool(ts_data.enabled) and ts_data.timestamp > 0 and len(ts_data.data) >= N


class RobotSource(threading.Thread):
    """Monitoring-port connection only. Reconnects automatically if the link drops."""

    def __init__(self, ip, on_sample):
        super().__init__(daemon=True)
        import mecademicpy.robot as mdr
        self._mdr = mdr
        self.robot = mdr.Robot()
        self.ip, self.on_sample = ip, on_sample
        self.stop_evt = threading.Event()
        self.description = ip
        self.payload = None
        self.missing = []        # names of streams not received
        self.status = ""         # connection status message shown in the header

    def connect(self):
        self.robot.Connect(address=self.ip, monitor_mode=True)
        try:
            info = self.robot.GetRobotInfo()
            self.description = f"{info.model} fw {info.version} @ {self.ip}"
        except Exception:
            pass

    def _reconnect(self):
        self.status = "monitoring connection lost - reconnecting..."
        while not self.stop_evt.wait(2.0):
            try:
                self.robot = self._mdr.Robot()
                self.connect()
                self.status = ""
                return True
            except Exception:
                pass
        return False

    def run(self):
        last_ts = None
        while not self.stop_evt.is_set():
            try:
                self.robot.WaitEndOfCycle(timeout=1.0)
                rt = self.robot.GetRobotRtData()
            except Exception:
                if self.stop_evt.is_set():
                    break
                if not self.robot.IsConnected() and not self._reconnect():
                    break
                continue
            fields = {"JointTorq": rt.rt_joint_torq, "TargetJointTorq": rt.rt_target_joint_torq,
                      "JointPos": rt.rt_joint_pos, "TargetJointVel": rt.rt_target_joint_vel}
            self.missing = [name for name, f in fields.items() if not _live(f)]
            meas = rt.rt_joint_torq
            if "JointTorq" in self.missing or meas.timestamp == last_ts:
                continue
            last_ts = meas.timestamp
            pos = rt.rt_joint_pos if "JointPos" not in self.missing else rt.rt_target_joint_pos
            if len(pos.data) < N:
                continue
            calc_ok = "TargetJointTorq" not in self.missing
            self.on_sample(Sample(
                t=meas.timestamp * 1e-6,
                q=np.radians(pos.data[:N]),
                qd=np.radians(rt.rt_target_joint_vel.data[:N]) if "TargetJointVel" not in self.missing else None,
                tau_meas=np.array(meas.data[:N], dtype=float),
                tau_calc=np.array(rt.rt_target_joint_torq.data[:N], dtype=float) if calc_ok else np.zeros(N),
                calc_ok=calc_ok,
            ))

    def close(self):
        self.stop_evt.set()
        try:
            self.robot.Disconnect()
        except Exception:
            pass


class SimSource(threading.Thread):
    """Fake Meca500 for testing without hardware: point-to-point moves with rests, a robot
    'calculated torque' without gravity, measured torque = true dynamics x unknown scale
    + friction + noise, and a short simulated contact on J2/J3 every third rest."""

    def __init__(self, chain, interval, on_sample, seed=1):
        super().__init__(daemon=True)
        self.chain, self.interval, self.on_sample = chain, interval, on_sample
        self.stop_evt = threading.Event()
        self.description = "simulated Meca500"
        self.payload = None
        self.missing, self.status = [], ""
        self.rng = np.random.default_rng(seed)
        self.true_scale = 0.9 * 100.0 / chain.effort      # 'real' max torque differs from URDF effort
        self.wp = [np.zeros(N)] + [self.rng.uniform(0.5 * chain.lower, 0.5 * chain.upper) for _ in range(40)]

    def run(self):
        move_T, rest_T, t = 2.5, 1.5, 0.0
        seg_T = move_T + rest_T
        stiction = np.zeros(N)
        while not self.stop_evt.is_set():
            k, tau_s = int(t // seg_T), t % seg_T
            a, b = self.wp[k % len(self.wp)], self.wp[(k + 1) % len(self.wp)]
            if tau_s < move_T:
                x = math.pi * tau_s / move_T
                q = a + (b - a) * (1 - math.cos(x)) / 2
                qd = (b - a) * math.pi / (2 * move_T) * math.sin(x)
                qdd = (b - a) * math.pi ** 2 / (2 * move_T ** 2) * math.cos(x)
            else:
                q, qd, qdd = b, np.zeros(N), np.zeros(N)
                if tau_s - move_T < self.interval:
                    stiction = self.rng.normal(0, 1.0, N)
            calc = self.true_scale * self.chain.rnea(q, qd, qdd, gravity=np.zeros(3))
            meas = self.true_scale * self.chain.rnea(q, qd, qdd) + 3.0 * np.tanh(qd / 0.02) \
                + (stiction if not qd.any() else 0) + self.rng.normal(0, 0.4, N)
            if k % 3 == 2 and 3.0 < tau_s < 3.12:  # simulated contact
                meas[1] += 18.0
                meas[2] -= 9.0
            self.on_sample(Sample(t, q.copy(), qd.copy(), meas, calc))
            t += self.interval
            time.sleep(self.interval)

    def connect(self):
        pass

    def close(self):
        self.stop_evt.set()


# ============================================================================ signal processing
def lowpass_alpha(fc, dt):
    return 1.0 - math.exp(-2.0 * math.pi * fc * dt) if fc > 0 else 1.0


class TorqueProcessor:
    def __init__(self, chain, scale, offset, mode, fc, rate_source, delta_thr, rate_thr,
                 peak_hold_s=2.0, csv_path=None):
        self.chain, self.scale, self.offset, self.mode = chain, scale, offset, mode
        self.fc, self.rate_source = fc, rate_source
        self.delta_thr, self.rate_thr, self.peak_hold_s = delta_thr, rate_thr, peak_hold_s
        self.lock = threading.Lock()
        self.events = deque(maxlen=6)
        self.n_samples, self.hz, self.t_prev = 0, 0.0, None
        self.calc_ok = True
        z = np.zeros(N)
        self.meas, self.model, self.delta, self.rate = z.copy(), z.copy(), z.copy(), z.copy()
        self.peak, self.peak_t = z.copy(), np.full(N, -1e9)
        self.q, self.qd, self.qdd = z.copy(), z.copy(), z.copy()
        self._src_f, self._q_prev, self._qd_prev = z.copy(), None, None
        self._armed = {"delta": np.ones(N, bool), "rate": np.ones(N, bool)}
        self.listeners = []  # callables(sample, processor) run on every sample (calibration)
        self._csv = None
        if csv_path:
            f = open(csv_path, "w", newline="")
            w = csv.writer(f)
            w.writerow(["t_s"] + [f"{k}_J{j + 1}" for k in ("meas", "model", "delta", "rate") for j in range(N)])
            self._csv = (f, w)

    def model_pct(self, s, qdd):
        if self.mode == "robot":
            return s.tau_calc
        if self.mode == "urdf":
            return self.scale * self.chain.rnea(s.q, self.qd, qdd) + self.offset
        return s.tau_calc + self.scale * self.chain.gravity(s.q) + self.offset   # robot+gravity

    def update(self, s: Sample):
        with self.lock:
            if self.t_prev is None or s.t <= self.t_prev:
                self.t_prev, self._q_prev = s.t, s.q
                self.qd = s.qd if s.qd is not None else np.zeros(N)
                self._qd_prev = self.qd
                self._src_f = s.tau_meas - self.model_pct(s, np.zeros(N)) if self.rate_source == "delta" \
                    else s.tau_meas.copy()
                return
            dt = s.t - self.t_prev
            self.t_prev = s.t
            self.hz += (1.0 / dt - self.hz) * (0.05 if self.hz else 1.0)
            a = lowpass_alpha(self.fc, dt)

            # velocity (streamed target, or derived from position) and filtered acceleration
            qd = s.qd if s.qd is not None else self.qd + a * ((s.q - self._q_prev) / dt - self.qd)
            self.qdd += a * ((qd - self._qd_prev) / dt - self.qdd)
            self.q, self.qd, self._q_prev, self._qd_prev = s.q, qd, s.q, qd

            self.meas = s.tau_meas
            self.model = self.model_pct(s, self.qdd)
            self.delta = self.meas - self.model
            self.calc_ok = s.calc_ok

            # filtered derivative: low-pass the signal, differentiate, low-pass again
            src = self.delta if self.rate_source == "delta" else self.meas
            prev = self._src_f.copy()
            self._src_f += a * (src - self._src_f)
            self.rate += a * ((self._src_f - prev) / dt - self.rate)

            now = time.monotonic()
            renew = (np.abs(self.rate) >= np.abs(self.peak)) | (now - self.peak_t > self.peak_hold_s)
            self.peak[renew], self.peak_t[renew] = self.rate[renew], now
            self._check("delta", self.delta, self.delta_thr, "%")
            self._check("rate", self.rate, self.rate_thr, "%/s")
            self.n_samples += 1
            if self._csv:
                self._csv[1].writerow([f"{s.t:.4f}"] + [f"{v:.3f}" for v in
                                      np.concatenate([self.meas, self.model, self.delta, self.rate])])
        for fn in self.listeners:
            fn(s, self)

    def _check(self, kind, values, thr, unit):
        if thr is None or thr <= 0:
            return
        armed = self._armed[kind]
        for j in range(N):
            if armed[j] and abs(values[j]) > thr:
                armed[j] = False
                label = "Δ" if kind == "delta" else "dΔ/dt" if self.rate_source == "delta" else "dτ/dt"
                self.log(f"J{j + 1}  {label} {values[j]:+.1f} {unit}  (thr {thr:g})")
            elif not armed[j] and abs(values[j]) < 0.7 * thr:
                armed[j] = True

    def log(self, msg, style="red"):
        self.events.appendleft((f"{datetime.now().strftime('%H:%M:%S.%f')[:-3]}  {msg}", style))

    def snapshot(self):
        with self.lock:
            return {k: (v.copy() if isinstance(v, np.ndarray) else v) for k, v in self.__dict__.items()
                    if k in ("meas", "model", "delta", "rate", "peak", "hz", "n_samples", "calc_ok")} | \
                   {"events": list(self.events)}

    def close(self):
        if self._csv:
            self._csv[0].close()


# ============================================================================ calibration
class CalibrationCollector:
    """Collects one averaged sample per static pose: measured - calculated [%] vs gravity [Nm]."""

    def __init__(self, chain, still_deg_s=0.3, settle_s=0.5, min_window_s=0.4, min_pose_change_deg=3.0):
        self.chain = chain
        self.still, self.settle, self.min_window = math.radians(still_deg_s), settle_s, min_window_s
        self.min_change = math.radians(min_pose_change_deg)
        self.lock = threading.Lock()
        self.poses = []          # list of (q, gravity_Nm, y_pct)
        self.state = "waiting"
        self._still_since, self._acc = None, []

    def on_sample(self, s, proc):
        with self.lock:
            moving = np.abs(proc.qd).max() > self.still
            if moving:
                self._close_window()
                self._still_since, self.state = None, "moving"
                return
            if self._still_since is None:
                self._still_since = s.t
            if s.t - self._still_since < self.settle:
                self.state = "settling"
                return
            self.state = "recording"
            self._acc.append((s.t, s.q, s.tau_meas - s.tau_calc))

    def _close_window(self):
        if self._acc and self._acc[-1][0] - self._acc[0][0] >= self.min_window:
            q = np.mean([a[1] for a in self._acc], axis=0)
            y = np.mean([a[2] for a in self._acc], axis=0)
            if not self.poses or min(np.abs(q - p[0]).max() for p in self.poses) > self.min_change:
                self.poses.append((q, self.chain.gravity(q), y))
        self._acc = []

    def finish(self):
        with self.lock:
            self._close_window()
            return list(self.poses)


def fit_calibration(chain, poses, min_poses=4, min_r2=0.8):
    default = 100.0 / chain.effort
    scale, offset = default.copy(), np.zeros(N)
    fitted, r2, rms_before, rms_after = [False] * N, [None] * N, [None] * N, [None] * N
    if len(poses) < min_poses:
        return scale, offset, fitted, r2, rms_before, rms_after
    G = np.array([p[1] for p in poses])
    Y = np.array([p[2] for p in poses])
    for j in range(N):
        g, y = G[:, j], Y[:, j]
        rms_before[j] = float(np.sqrt(np.mean((y - default[j] * g) ** 2)))
        if np.ptp(g) < 0.1 * chain.effort[j]:   # gravity barely changes on this joint: keep default
            continue
        A = np.column_stack([g, np.ones_like(g)])
        (s, b), *_ = np.linalg.lstsq(A, y, rcond=None)
        res = y - A @ np.array([s, b])
        r2[j] = float(1 - res.var() / y.var()) if y.var() > 0 else None
        if r2[j] is None or r2[j] < min_r2:   # weak fit (stiction/noise dominate): keep default
            continue
        scale[j], offset[j], fitted[j] = s, b, True
        rms_after[j] = float(np.sqrt(np.mean(res ** 2)))
    return scale, offset, fitted, r2, rms_before, rms_after


def load_calibration(path, chain):
    scale, offset, src = 100.0 / chain.effort, np.zeros(N), "URDF effort limits (uncalibrated)"
    if path and os.path.exists(path):
        with open(path) as f:
            c = json.load(f)
        scale = np.array(c["scale_pct_per_nm"], dtype=float)
        offset = np.array(c["offset_pct"], dtype=float)
        src = f"{os.path.basename(path)} ({c.get('n_poses', '?')} poses, {c.get('date', '')[:10]})"
    return scale, offset, src


# ============================================================================ display
BLOCKS = " ▏▎▍▌▋▊▉█"


def hbar(frac, width):
    """Left-anchored bar with 1/8 character resolution, frac in [0, 1]."""
    frac = min(max(frac, 0.0), 1.0)
    eighths = int(round(frac * width * 8))
    full, rem = divmod(eighths, 8)
    s = "█" * full + (BLOCKS[rem] if rem and full < width else "")
    return s + " " * (width - len(s))


def cbar(value, vmax, half):
    """Centered bar: negative values grow left, positive values grow right of '│'."""
    n = int(round(min(abs(value) / vmax, 1.0) * half)) if vmax > 0 else 0
    left = " " * half if value >= 0 else " " * (half - n) + "█" * n
    right = "█" * n + " " * (half - n) if value >= 0 else " " * half
    return left, right


def level_style(x, thr, warn=0.5):
    if thr is None or thr <= 0:
        return "cyan"
    return "red bold" if abs(x) >= thr else "yellow" if abs(x) >= warn * thr else "green"


def render(proc, header, args, extra=None, width=120, src=None):
    s = proc.snapshot()
    rate_lbl = "dΔ/dt" if args.rate_source == "delta" else "dτ/dt"
    dmax = 2 * args.delta_threshold if args.delta_threshold else 20.0
    # bar widths adapt to the terminal: ~64 columns are taken by numbers, padding and borders
    avail = width - 64
    load_w = min(max(avail // 2, 6), 20)
    half = min(max((avail - load_w) // 2, 3), 12)

    tbl = Table(expand=False, header_style="bold", box=None, padding=(0, 1))
    tbl.add_column("Joint", justify="center", no_wrap=True)
    tbl.add_column("Load\n|τ| % max", no_wrap=True)
    tbl.add_column("Meas\n%", justify="right", no_wrap=True)
    tbl.add_column("Model\n%", justify="right", no_wrap=True)
    tbl.add_column(f"Δ = meas − model\n(bar ±{dmax:g}%)", justify="center", no_wrap=True)
    tbl.add_column(f"{rate_lbl}\n%/s", justify="right", no_wrap=True)
    tbl.add_column("peak\n%/s", justify="right", no_wrap=True)
    for j in range(N):
        m, d, r, p = s["meas"][j], s["delta"][j], s["rate"][j], s["peak"][j]
        load_style = "green" if abs(m) < 50 else "yellow" if abs(m) < 80 else "red bold"
        load = Text(hbar(abs(m) / 100.0, load_w), style=load_style) + Text(f" {abs(m):5.1f}")
        ds = level_style(d, args.delta_threshold)
        l, rr = cbar(d, dmax, half)
        delta = Text(l, style=ds) + Text("│", style="dim") + Text(rr, style=ds) + Text(f" {d:+6.1f}", style=ds)
        tbl.add_row(f"J{j + 1}", load, f"{m:+6.1f}", f"{s['model'][j]:+6.1f}", delta,
                    Text(f"{r:+6.0f}", style=level_style(r, args.rate_threshold)),
                    Text(f"{p:+6.0f}", style=level_style(p, args.rate_threshold)))

    head = Text.assemble(("Meca500 torque monitor", "bold cyan"), "  ·  ", header,
                         "  ·  ", (f"{s['hz']:.0f} Hz", "bold"), f"  ·  {s['n_samples']} samples")
    lines = [head]
    if src is not None and src.status:
        lines.append(Text(f"! {src.status}", style="yellow bold"))
    missing = list(src.missing) if src is not None else []
    if "JointTorq" in missing:
        lines.append(Text("! Measured torque (JointTorq) is not streamed - waiting. Another client probably "
                          "replaced the stream list (SetRealTimeMonitoring is not cumulative). Restart this "
                          f"tool while the control port is free, or call in your program: {STREAMS_LINE}",
                          style="red bold"))
    elif missing:
        fallback = {"TargetJointTorq": "robot calculated torque = 0", "JointPos": "using target position",
                    "TargetJointVel": "velocity derived from position"}
        lines.append(Text("! Not streamed: " + ", ".join(f"{m} ({fallback[m]})" for m in missing)
                          + f". To enable: {STREAMS_LINE}", style="yellow"))
    lines += [Text(""), tbl, Text("")]

    ev = Text()
    for i, (msg, style) in enumerate(s["events"]):
        ev.append(("\n" if i else "") + msg, style=style)
    if not s["events"]:
        ev.append("no threshold crossings yet", style="dim")
    lines.append(Panel(ev, title="events", title_align="left", border_style="dim"))
    if extra is not None:
        lines.append(extra)
    lines.append(Text(f"Δ threshold ±{args.delta_threshold:g} %   ·   {rate_lbl} threshold ±{args.rate_threshold:g} %/s"
                      f"   ·   filter {args.filter_hz:g} Hz   ·   Ctrl+C to quit", style="dim"))
    return Panel(Group(*lines), border_style="cyan")


def calib_status(collector):
    with collector.lock:
        n, state = len(collector.poses), collector.state
    style = {"recording": "green", "settling": "yellow"}.get(state, "dim")
    return Panel(Text.assemble(f"poses collected: ", (f"{n}", "bold"), "   robot: ", (state, style),
                               "\nJog the robot (web portal or your program) and rest ~2 s in each pose. "
                               "Vary J2, J3, J5 (and J4 with J5 bent); 8+ poses. Ctrl+C to fit and save."),
                 title="calibration", title_align="left", border_style="magenta")


def print_fit(console, chain, scale, offset, fitted, r2, rms_b, rms_a, n):
    t = Table(title=f"Calibration fit ({n} static poses):  meas% − calc% = scale · gravity_Nm + offset",
              header_style="bold")
    for c in ("Joint", "fitted", "scale %/Nm", "→ max torque Nm", "URDF effort Nm", "offset %", "R²",
              "RMS before %", "RMS after %"):
        t.add_column(c, justify="right")
    f = lambda v, fmt: "–" if v is None else format(v, fmt)
    for j in range(N):
        t.add_row(f"J{j + 1}", "yes" if fitted[j] else "no (default)", f"{scale[j]:.2f}",
                  f"{100 / scale[j]:.2f}" if scale[j] else "–", f"{chain.effort[j]:g}", f"{offset[j]:+.2f}",
                  f(r2[j], ".3f"), f(rms_b[j], ".2f"), f(rms_a[j], ".2f"))
    console.print(t)
    if any(f and sc < 0 for f, sc in zip(fitted, scale)):
        console.print("[yellow]Negative scale on some joint: the robot's torque sign convention is opposite "
                      "to the URDF joint axis there. The fitted (negative) scale corrects it.[/yellow]")
    if not any(fitted):
        console.print("[yellow]No joint could be fitted (not enough gravity variation between poses, or "
                      "R² < 0.8). Use more varied poses (large J2, J3, J5 changes).[/yellow]")


# ============================================================================ main
def parse_args():
    p = argparse.ArgumentParser(description="Meca500 live joint torque monitor (measured vs model)",
                                formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--ip", default="192.168.0.100", help="robot IP address")
    p.add_argument("--urdf", default=os.path.join(HERE, "meca500.urdf"), help="URDF with link inertias")
    p.add_argument("--model", choices=("robot+gravity", "urdf", "robot"), default="robot+gravity",
                   help="what the measured torque is compared to")
    p.add_argument("--calib", default=DEFAULT_CALIB, help="calibration JSON to load (if it exists)")
    p.add_argument("--payload-mass", type=float, default=None,
                   help="payload [kg]; default: read from robot (GetPayload)")
    p.add_argument("--payload-com", type=float, nargs=3, default=(0, 0, 0), metavar=("X", "Y", "Z"),
                   help="payload center of mass in flange frame [mm]")
    p.add_argument("--delta-threshold", type=float, default=10.0, help="|Δ| alarm threshold [%%]")
    p.add_argument("--rate-threshold", type=float, default=300.0, help="|dΔ/dt| alarm threshold [%%/s]")
    p.add_argument("--rate-source", choices=("delta", "measured"), default="delta",
                   help="differentiate the delta (default) or the raw measured torque")
    p.add_argument("--filter-hz", type=float, default=8.0, help="low-pass cutoff used for the derivative")
    p.add_argument("--monitor-interval", type=float, default=0.005,
                   help="monitoring interval set during setup [s] (0 = leave the robot's current value)")
    p.add_argument("--no-setup", action="store_true",
                   help="skip the control-mode setup, only use streams already enabled on the robot")
    p.add_argument("--refresh", type=float, default=10.0, help="screen refresh rate [Hz]")
    p.add_argument("--csv", default=None, help="log every sample to this CSV file")
    p.add_argument("--calibrate", metavar="OUT_JSON", default=None,
                   help="calibration mode: collect static poses, fit scale/offset, save to OUT_JSON")
    p.add_argument("--sim", action="store_true", help="simulated robot (no hardware needed)")
    return p.parse_args()


def main():
    args = parse_args()
    console = Console()

    chain = SerialChain.from_urdf(args.urdf)
    if chain.n != N:
        console.print(f"[red]URDF has {chain.n} revolute joints, expected {N}[/red]")
        return 1
    scale, offset, calib_src = load_calibration(None if args.calibrate else args.calib, chain)
    if args.calibrate:
        args.model = "robot+gravity"   # calibration fits the gravity part only

    holder = {}
    on_sample = lambda s: holder["proc"].update(s)

    robot_payload = None
    if not args.sim and not args.no_setup:
        console.print(f"Setup on {args.ip} (control port, a few seconds)...")
        try:
            robot_payload = setup_robot(args.ip, args.monitor_interval, lambda m: console.print(f"  · {m}"))
            console.print("  · control released")
        except Exception as e:
            console.print(f"[yellow]  · setup skipped, control port not available ({str(e).splitlines()[0]}).\n"
                          f"    Using the streams already enabled on the robot.[/yellow]")

    src = SimSource(chain, 0.005, on_sample) if args.sim else RobotSource(args.ip, on_sample)
    console.print(f"Connecting to {'simulator' if args.sim else args.ip + ' (monitoring port)'} ...")
    try:
        src.connect()
    except Exception as e:
        console.print(f"[red]Connection failed:[/red] {e}")
        console.print("Check the IP and that the robot is powered on.")
        return 1

    if args.payload_mass is not None:
        payload, payload_src = (args.payload_mass, tuple(args.payload_com)), "args"
    elif robot_payload is not None:
        payload, payload_src = robot_payload, "robot"
    else:
        payload, payload_src = (0.0, (0.0, 0.0, 0.0)), "unknown, use --payload-mass"
    chain.set_payload(payload[0], np.array(payload[1]) / 1000.0)

    proc = TorqueProcessor(chain, scale, offset, args.model, args.filter_hz, args.rate_source,
                           args.delta_threshold, args.rate_threshold, csv_path=args.csv)
    holder["proc"] = proc
    collector = None
    if args.calibrate:
        collector = CalibrationCollector(chain)
        proc.listeners.append(collector.on_sample)

    header = Text.assemble(src.description, "  ·  model ", (args.model, "bold"),
                           f"  ·  payload {payload[0]:.3f} kg ({payload_src})  ·  calib: {calib_src}")

    src.start()
    try:
        with Live(render(proc, header, args, width=console.width, src=src), console=console,
                  refresh_per_second=args.refresh, screen=False) as live:
            while True:
                live.update(render(proc, header, args, calib_status(collector) if collector else None,
                                   width=console.width, src=src))
                time.sleep(1.0 / args.refresh)
    except KeyboardInterrupt:
        pass
    finally:
        src.close()
        proc.close()

    if collector:
        poses = collector.finish()
        sc, off, fitted, r2, rb, ra = fit_calibration(chain, poses)
        if len(poses) < 4:
            console.print(f"[red]Only {len(poses)} static poses collected (need ≥ 4) - nothing saved.[/red]")
            return 1
        print_fit(console, chain, sc, off, fitted, r2, rb, ra, len(poses))
        with open(args.calibrate, "w") as f:
            json.dump({
                "date": datetime.now().isoformat(timespec="seconds"),
                "urdf": os.path.abspath(args.urdf),
                "payload_kg": payload[0], "payload_com_mm": list(payload[1]),
                "n_poses": len(poses),
                "scale_pct_per_nm": sc.tolist(), "offset_pct": off.tolist(),
                "implied_max_torque_nm": (100.0 / sc).tolist(),
                "fitted": fitted, "r2": r2,
            }, f, indent=2)
        console.print(f"[green]Saved {args.calibrate}[/green]  (loaded automatically if it is "
                      f"{os.path.basename(DEFAULT_CALIB)} next to the script, otherwise pass --calib)")
    else:
        console.print("Stopped.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
